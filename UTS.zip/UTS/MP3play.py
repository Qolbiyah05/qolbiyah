from playsound import playsound

playsound ("musik.mp3",True) 