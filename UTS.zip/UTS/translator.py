import tkinter as tk
from tkinter import ttk
from googletrans import Translator

class TranslatorApp:
    def _init_(self, root):
        self.root = root
        self.root.title("Simple Translator App")

        self.source_label = ttk.Label(root, text="Source Language:")
        self.source_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.source_lang = ttk.Combobox(root, values=list(LANGUAGES.keys()))
        self.source_lang.set("English")
        self.source_lang.grid(row=0, column=1, padx=10, pady=10)

        self.target_label = ttk.Label(root, text="Target Language:")
        self.target_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.target_lang = ttk.Combobox(root, values=list(LANGUAGES.keys()))
        self.target_lang.set("Select Language")
        self.target_lang.grid(row=1, column=1, padx=5, pady=5)

        self.text_label = ttk.Label(root, text="Enter Text:")
        self.text_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.text_entry = ttk.Entry(root, width=20)
        self.text_entry.grid(row=2, column=1, padx=10, pady=10)

        self.translate_button = ttk.Button(root, text="Translate", command=self.translate_text)
        self.translate_button.grid(row=3, column=0, columnspan=2, pady=10)

        self.result_label = ttk.Label(root, text="Translation Result:")
        self.result_label.grid(row=4, column=0, padx=10, pady=10, sticky="w")

        self.result_text = tk.Text(root, height=5, width=20)
        self.result_text.grid(row=4, column=1, padx=10, pady=10)

    def translate_text(self):
        translator = Translator()
        source_lang = LANGUAGES[self.source_lang.get()]
        target_lang = LANGUAGES[self.target_lang.get()]
        text_to_translate = self.text_entry.get()

        translation = translator.translate(text_to_translate, src=source_lang, dest=target_lang)

        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, translation.text)

# Language Codes
LANGUAGES = {
    "Afrikaans": "af",
    "Albanian": "sq",
    "Amharic": "am",
    "Arabic": "ar",
    "Armenian": "hy",
    "Azerbaijani": "az",
    # ... (Tambahkan lebih banyak bahasa jika diperlukan)
}

if __name__== "_main_":
 root = tk.Tk()
 app = TranslatorApp(root)
 root.mainloop()